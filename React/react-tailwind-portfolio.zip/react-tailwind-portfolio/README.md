
# React + Tailwind Portfolio Suite

Three distinct sites (SaaS dashboard, rustic restaurant, newspaper blog) bundled in one React app with reusable components and SVG banners.


---

## Prerequisites
- **Node.js 18+** (recommended LTS). Verify:
  ```bash
  node -v
  npm -v
  ```
- A terminal (PowerShell on Windows, Terminal on macOS/Linux).

---

## Quick Start
1) Unzip the project and open a terminal in the folder:
   ```bash
   cd WebsitePortfolio/React
   ```
2) Install dependencies:
   ```bash
   npm install
   ```
3) Run the dev server:
   ```bash
   npm run dev
   ```
   Open the local URL it prints (usually `http://localhost:5173`).

4) Build for production (optional):
   ```bash
   npm run build
   npm run preview   # serves the built app locally
   ```

---

## Scripts
- `npm run dev` — starts the Vite dev server  
- `npm run build` — builds production assets into `dist/`  
- `npm run preview` — serves `dist` locally for a quick sanity check

---

## Project Structure
```
react-tailwind-portfolio/
├─ index.html
├─ package.json
├─ postcss.config.js
├─ tailwind.config.js
├─ vite.config.js
└─ src/
   ├─ main.jsx
   ├─ App.jsx          # tabs for three distinct sites
   └─ index.css        # Tailwind layers
```

**App.jsx** renders three distinct designs via simple tabs:
- **Nova Metrics** — cyber/neon SaaS dashboard (dark, glassmorphism)
- **Ember & Thyme** — rustic/print bistro (serif + paper vibe)
- **Bit by Bit** — newspaper-style tech blog (two-column, drop caps)

Banners are lightweight **SVGs** (no external images) and accessible with `role="img"` + `aria-label`.

---

## Tailwind Notes
This project uses the **Typography** plugin. If you see this error:
```
plugin:vite:css] [postcss] Cannot find module '@tailwindcss/typography'
```
Install it:
```bash
npm i -D @tailwindcss/typography
```

Prefer ESM in `tailwind.config.js`?
```js
// tailwind.config.js (ESM)
import typography from '@tailwindcss/typography'

/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: { extend: {} },
  plugins: [typography],
}
```

---

## Customization
- **Default tab** (Nova/Ember/Blog):
  ```js
  const [active, setActive] = React.useState("nova"); // "ember" or "blog"
  ```
- **Brand colors/fonts**: Adjust Tailwind classes or extend the theme in `tailwind.config.js`.
- **Images/Banners**: Swap `GradientBanner` for real `<img>` assets, or tweak its props for different colors/labels.
- **Components**: Extract blocks (Hero, Card, ArticleCard, MenuList) into `src/components/` for reuse.

---

## Deployment
**Vercel**
1. Push the folder to GitHub.
2. Import the repo on vercel.com → Framework: *Vite* → build: `npm run build` → output: `dist`.
3. Deploy.

**Netlify**
1. New site → Import from Git → Build command `npm run build` → Publish directory `dist`.

**GitHub Pages**
1. Build locally: `npm run build`
2. Serve `/dist` via Pages (e.g., `gh-pages` branch or an action).

---

## Troubleshooting
- **Typography plugin not found**: `npm i -D @tailwindcss/typography`.
- **“npm: command not found”**: Install Node.js (v18+) and restart the terminal.
- **Port already in use**: Vite will offer another port—accept it or stop the other app.
- **Blank page / 404 on refresh in production**: Ensure SPA fallback to `index.html` (configure host redirects).
- **Windows path/permissions**: If installs fail, try PowerShell as admin; avoid OneDrive-protected folders for dev caches.

---

## License
For portfolio/demo use. Replace text and brand elements as needed before publishing.
